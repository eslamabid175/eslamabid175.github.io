# Task: none
status: none

No active task. Start one with /task-state start <title> (or /plan, /feature).
